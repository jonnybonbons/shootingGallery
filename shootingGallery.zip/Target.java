public class Target
{
    int x,y,w,h,n,r;
    boolean removal = false;
    double m;
    double theta;
    Target() {}

    void move() {}
}